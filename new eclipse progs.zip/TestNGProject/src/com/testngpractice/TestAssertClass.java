package com.testngpractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestAssertClass {

	public static WebDriver driver;
@Test
	
	public void AssertExampleProgram()
	{
		
		WebDriverManager.chromedriver().setup();
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://in.search.yahoo.com/?fr2=inr");
		
		String ActualTitle = driver.getTitle();
		
		System.out.println("The Actual Page Title" +ActualTitle);
		
		//Assert is uses to compare two values of any data type
		//once the script got failed at any step the test will fail in assertion
		//Assert.assertEquals(ActualTitle, "Google Search");
		
		//Even though the assertion is failure we can use Soft Assert class to continue our code
		
				SoftAssert s1 = new SoftAssert();
				
				s1.assertEquals(ActualTitle, "Google Search");
		
		
		driver.quit();
		
		s1.assertAll();
		
		
	}
}
