package com.testngpractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtentReportExample {

public static WebDriver driver;
	
	@Test
	
	public void AmazonTestcase1()
	{
		WebDriverManager.chromedriver().setup();
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.amazon.in/");
		
		WebElement SearchBox = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
		
		SearchBox.sendKeys("Shirts");
}
	
	WebElement SearchIcon = driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
	
	SearchIcon.click();
	
	//To verify it from the URL Parameters
	
	String CurrentURL = driver.getCurrentUrl();
	
	System.out.println(CurrentURL);
	
	if(CurrentURL.contains("Shirts"))
	{
		System.out.println("The Page is redirected to shirts correctly");
	}
	else
	{
		System.out.println("URL Redirection error");
	}
	
	driver.quit();
}
