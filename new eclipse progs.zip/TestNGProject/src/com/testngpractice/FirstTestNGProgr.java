package com.testngpractice;

import org.testng.Assert;
import org.testng.annotations.Test;

public class FirstTestNGProgr {
@Test
	
	public void Testcase1()
	{
		System.out.println("Test case1");
	}
	
	@Test
	
	public void Testcase2()
	{
		System.out.println("Test case2");
		
		Assert.fail();
	}
}
