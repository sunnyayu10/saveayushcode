package com.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPageObj {
		
		//This pattern in normal java technique of implmenting POM
		
		@Test
			
			public void LoginTestcase()
			{
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				
				driver.manage().window().maximize();
				
				driver.get("https://the-internet.herokuapp.com/login");
				
				LoginPageObj lp = new LoginPageObj(driver);
				
				lp.enterusername("tomsmith");
				lp.enterpassword("SuperSecretPassword!");
				
				//This type is to make the webelement declared without doing any action on the Page objects
				lp.submiButton().click();
				
				driver.quit();
				
			}
		public WebDriver driver;
			
			By userid = By.name("username");
			By password = By.id("password");
			By submitButton = By.className("radius");

			
			public LoginPageObj(WebDriver driver)
			{
				this.driver = driver;
			}
			
			public void enterusername(String testdata)
			{
				driver.findElement(userid).sendKeys(testdata);
			
			}
			public WebElement userName()
			{
				return driver.findElement(userid);
			}
			
			public void enterpassword(String testdata)
			{
				driver.findElement(password).sendKeys(testdata);
			}

			public WebElement submiButton()
			{
				return driver.findElement(submitButton);
			}
}
