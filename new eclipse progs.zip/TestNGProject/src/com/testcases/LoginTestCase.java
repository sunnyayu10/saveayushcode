package com.testcases;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObj;
import com.pageobjects.LoginPageObj.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTestCase {
	
	public static ExtentTest test;
	public static ExtentReports report;
	
	LoginPageObj lp;
	
	@BeforeMethod
	
	public void StartBrowser()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://the-internet.herokuapp.com/login");
		lp = new LoginPageObj(driver);
		
	}

@Test
	
	public void LoginTestcase()
	{
	
		lp.enterusername("tomsmith");
		lp.enterpassword("SuperSecretPassword!");
		
		//This type is to make the webelement declared without doing any action on the Page objects
		lp.Rachana().click();
		
	
		
	}
	
	@Test
	
	public void NegativeLogin()
	{
		
		lp.enterusername("VEMU PREM");
		lp.userName().clear();
		lp.enterusername("Atheka");
		lp.enterpassword("Neha");
		
		//This type is to make the webelement declared without doing any action on the Page objects
		lp.Rachana().click();
		
	
	}
}
