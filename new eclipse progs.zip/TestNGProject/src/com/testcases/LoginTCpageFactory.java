package com.testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pageobjects.PageFactoryExample;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTCpageFactory {
	
	PageFactoryExample pf;

@BeforeMethod
	
	public void StartBrowser()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://the-internet.herokuapp.com/login");
		pf = new PageFactoryExample(driver);
		
	}

	@Test
	
	public void LoginTestcase()
	{
	
		pf.EnterUserName("tomsmith");
		
		//Calling a Page Facotory Element 
		
		PageFactoryExample.UserID.sendKeys("Neha");
	//	pf.enterpassword("SuperSecretPassword!");
		
		//This type is to make the webelement declared without doing any action on the Page objects
		//lp.Rachana().click();

	}
}
