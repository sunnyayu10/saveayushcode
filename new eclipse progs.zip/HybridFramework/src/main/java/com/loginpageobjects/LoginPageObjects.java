package com.loginpageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObjects {

	public WebDriver driver;

	By userid = By.name("email");

	By password = By.name("password");

	By submitButton = By.xpath("(//button[@type='submit'])[1]");

	public LoginPageObjects(WebDriver driver)

	{

		this.driver = driver;

	}

	public void enterusername(String testdata)

	{

		driver.findElement(userid).sendKeys(testdata);

	}

	public WebElement userName()

	{

		return driver.findElement(userid);

	}

	public void enterpassword(String testdata)

	{

		driver.findElement(password).sendKeys(testdata);

	}
}
