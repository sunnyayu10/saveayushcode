package com.logintestcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.loginpageobjects.LoginPageObjects;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTestCase {

	public static WebDriver driver;

	LoginPageObjects lp;

	@BeforeMethod

	public void StartBrowser()

	{

		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://automationexercise.com/login");

		lp = new LoginPageObjects(driver);

	}

	@Test

	public void LoginTestcase()

	{

		lp.enterusername("tomsmith");

		lp.enterpassword("SuperSecretPassword!");

		lp.SubmitButton().click();

		// This type is to make the webelement declared without doing any action on the
		// Page objects

	}

	@AfterMethod

	public void CloseBrowser()

	{

		driver.quit();

	}
}
