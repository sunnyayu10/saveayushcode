package com.collectionprog;
import java.util.HashSet;
import java.util.Set;

public class SetInterfaceClass {
	public static void main(String args[])
	{
		Set<String> s1 = new HashSet<String>();
		
		s1.add("Apple");
		s1.add("Orange");
		s1.add("fruit");
		s1.add("grape");
		s1.add("one");
		s1.add("one");
		s1.add("two");
		
		System.out.println("Printing the set");
		System.out.println(s1);
		
		
		System.out.println(s1.size());
		System.out.println(s1.isEmpty());
		
		//To remove an element 
		
		//s1.remove("Orange");
		
		System.out.println(s1);
	
}
}