package com.collectionprog;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListClassExample {
	public static void main(String args[])
	{
		//We are creating a list to save some values (List is interface and Arraylist is class)
		List a1 = new ArrayList();
		
		a1.add("Priya");
		a1.add("Eugene");
		a1.add("Malar");
		a1.add("Prem");
		
		System.out.println("Print the elements in the list");
		System.out.println(a1);
		
		//Using Iterator we traverse into the list from forward and backward
		
		ListIterator<String> itr = a1.listIterator();
		
		
		System.out.println("Printing from forward order");
		while (itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		//To do it in backward direction
		
		System.out.println("Printing from reverse order");
		
		while (itr.hasPrevious())
		{
			System.out.println(itr.previous());
		}
		
		//Array list can grow automatically, there is no fixed size, hold duplicate elements
		
				ArrayList<String> a2 = new ArrayList<String>();
				
				a2.add("One"); //index 0
				a2.add("Two"); //index 1
				a2.add("Three"); // index 2
				a2.add("Four"); //index 3
				
				a2.add("One");
				
				System.out.println("The size of the ArrayList" +a2.size()); //to find size of array(size will be total elements and index will be one less)
				
				//Adding the elements by giving the index location
				a2.add(3,"Five"); //we can add  new element in between given list
				
				//Printing the array after adding an element
				
				System.out.println(a2);
				
				//Printing the array size post adding new element
				
				System.out.println("The size of the ArrayList" +a2.size());
				
				// To get the elements from the array we use get() method
				
				System.out.println(a2.get(3));
				
				//To get the index of an element in array
				
				System.out.println(a2.indexOf("Two"));
				
				//If we want to get the index of the last element of the array list
				
				System.out.println("Last indexd of one is: " +a2.lastIndexOf("One"));
	}
}
