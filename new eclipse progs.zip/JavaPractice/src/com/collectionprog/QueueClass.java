package com.collectionprog;
import java.util

public class QueueClass {
	public static void main(String args[])
	{
		//Create a new queue
		
		Queue q1 = new LinkedList();
		
		//Inserting elements in a queue
		
		q1.add("three");
		q1.add("two");
		q1.add("one");
		
		
		//to print queue
		
		System.out.println(q1);
		
		//The first element added will be removed from the list
		q1.remove();
		
		System.out.println(q1);
		
		q1.add("three");
		
		System.out.println(q1);
		
	}
}
