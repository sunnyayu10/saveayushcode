package com.collectionprog;
import java.util.HashMap;
import java.util.Map;


public class MapClassInterface {
	public static void main(String args[])
	{
		//Creating a map with key and value
		Map <Integer, String> m1 = new HashMap<Integer, String>();
		
		//To add items to Map we use put method
		
		m1.put(1, "One");
		m1.put(2, "Two");
		m1.put(3, "Threee");
		
		//print the map values
		
		System.out.println(m1);
		
		m1.put(11, "Harish");
		
		System.out.println(m1);
		
		m1.put(11, "Priya");
		
		System.out.println(m1);
		
		//Get any specified element from map
		
		System.out.println(m1.get(11));
		//Map will throw null if the key is not defined in your map interface
		System.out.println(m1.get(10));
		
		//To check if the map key value is there or not
		
		System.out.println(m1.containsKey(11));
		
		//To check if an element is there in a map
		
		System.out.println(m1.containsValue("Priya"));
	}
}
