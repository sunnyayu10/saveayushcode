package com.testprogrammes;

class AutomationBatch {
	String Student1 = "Priya";
	String Student2 = "Azee";
	String Student3 = "Sankalp";

	int a = 10;

	public void Marks() {

		int Student1Mark = 100;
	}

}

public class demo1 {

	// Global Variable Declaration
	int a = 10;

	int globalvariable = 20;

	public void print() {
		// local variable declaration
		int a = 20;

		System.out.println("***Print Method***");
		System.out.println("Print 1");

		System.out.println("Local variable:" + a);

		System.out.println("Global variable:" + globalvariable);
	}

	public static void main(String args[]) {

		// Syntax - Class Name object name = new ClassName();

		demo1 obj1 = new demo1();

		System.out.println(obj1.a);

		System.out.println(obj1.globalvariable);

		obj1.print();
	}

}
