package com.testprogrammes;

public class OperatorsEx {
	public static void main(String args[]) {
	//Relational Operators
	
	int x = 10;
	int y =20;
	int z = 30;
	int J = 10;
	
	if(x>y)
	{
		System.out.println("X is greater than Y");
	}
	
	if(x<y)
	{
		System.out.println("X is lesserr than Y");
	}
	
	if(x==J)
	{
		System.out.println("X and J are Equal");
	}
	
	if(x!=z)
	{
		System.out.println("X is not equal to Z");
	}
	}
}
