package com.testprogrammes;

public class SwitchCase {
	public static void main(String args[])
	{
		
		int day =1;
		String weekday = "Not Defined";
		
		switch(day)
		{
		case 1: weekday ="Monday";
				break;
		case 2: weekday ="Tuesday";
				break;
		case 3: weekday ="Wednesday";
				break;
		
		}
		
		System.out.println(weekday);
	}
}
