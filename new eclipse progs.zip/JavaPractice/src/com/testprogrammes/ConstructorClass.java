package com.testprogrammes;

public class ConstructorClass {
	public void print()
	{
		
		System.out.println("Normal Method");
	}
	
	//Default method for your class

	ConstructorClass()
	{
		System.out.println("This is a constructor");
		
	}
	
	//Parameterized Constructor
	ConstructorClass(int a, int b)
	{
		int c = a+b;
		System.out.println(c);
		System.out.println("Parameterized Constructor");
	}
	
	//ConstructorOverloading
	ConstructorClass(int a, String b)
	{
		System.out.println("print int and string values");
	}
	
	public static void main(String args[])
	{
		ConstructorClass c1 = new ConstructorClass();

		ConstructorClass c2 = new ConstructorClass(5,5);
	
}}
