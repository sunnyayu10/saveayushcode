package com.testprogrammes;

public class StaticMethods {
public static int a = 10;
	
	public void print()
	{
		System.out.println("Normal Method");
	}
	
	
	public boolean Results()
	{
		return true;
		
	}
	
	public static void staticPrint()
	{
		System.out.println("Priting Static Method");
	}
	
	
	public static void main(String args[])
	{
		StaticMethods obj1 = new StaticMethods();
		
		obj1.print();
		System.out.println(obj1.Results());
		
		staticPrint();
		
		System.out.println(a);
		
	}

}
