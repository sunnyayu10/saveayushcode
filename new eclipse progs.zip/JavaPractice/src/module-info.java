/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module JavaPractice {
}