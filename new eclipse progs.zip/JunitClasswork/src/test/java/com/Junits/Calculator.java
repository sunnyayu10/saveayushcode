package com.Junits;

public class Calculator {

	public static int add(int a, int b) {
	 int result = a + b;
	 return result;
	}
	
	public static int sub(int a, int b) {
		int result = a+b;
		return result;
	}
}
