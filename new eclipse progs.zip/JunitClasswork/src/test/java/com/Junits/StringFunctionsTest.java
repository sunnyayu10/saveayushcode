package com.Junits;

import org.junit.jupiter.api.Assertions;

public class StringFunctionsTest {

	public void test() {
		Assertions.assert
	}
}
