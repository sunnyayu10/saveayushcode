package com.Junits;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CalculatorTest {
		
		@Test
		public void test1() {
			int result = Calculator.add(6, 7);
			Assertions.assertEquals(13,result);

			}

		@Test
		public void test2() {
			int result = Calculator.sub(8, 6);
			Assertions.assertEquals(14,result);
		}
	}


