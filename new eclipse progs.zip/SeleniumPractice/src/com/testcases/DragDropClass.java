package com.testcases;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragDropClass {
	public static void main(String args[]) throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "./BrowserUtils/chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	
	driver.get("https://jqueryui.com/droppable/");
	
	WebElement iFrame = driver.findElement(By.xpath("//iframe[@class='demo-frame']"));
	
	driver.switchTo().frame(iFrame);
	Thread.sleep(3000);
	
	WebElement DragFrom = driver.findElement(By.id("draggable"));
	
	WebElement DropTo = driver.findElement(By.id("droppable"));
	
	Actions a1 = new Actions(driver);
	
	a1.dragAndDrop(DragFrom, DropTo).build().perform();   //to see its meaning?
	Thread.sleep(4000);
	driver.close();
}
}
