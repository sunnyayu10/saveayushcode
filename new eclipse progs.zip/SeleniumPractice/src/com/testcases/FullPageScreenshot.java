package com.testcases;

public class FullPageScreenshot {

}
