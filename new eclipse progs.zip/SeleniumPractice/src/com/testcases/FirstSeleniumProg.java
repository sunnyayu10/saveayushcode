package com.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstSeleniumProg {
	public static void main(String args[]) throws InterruptedException
	{
		//Step 1 - Set the location of the browser utils exe in the program
		
		System.setProperty("webdriver.chrome.driver", "./BrowserUtils/chromedriver.exe");
		
		
		//Step 2 - Create an object for ChromeDriver with respect to WebDriver interface
		
		WebDriver driver = new ChromeDriver();
		
		//Best Practice to follow is to maximize the browser before running the test
		
		driver.manage().window().maximize();
		
		//Give the URL to be navigated, we use get method to navigate to a URL
		
		driver.get("https://the-internet.herokuapp.com/login");
		
        driver.navigate().to("https://www.google.com");
        
		
		//To navigate back of browser to previous page
		
		driver.navigate().back();
		Thread.sleep(3000);
		
		//To navigate forward 
		
		driver.navigate().forward();
		 Thread.sleep(5000);
		
		
		//Automatically close the browser session
		driver.close();
	}
}
